#!/usr/bin/env bash
# Tüm testler. Girdi enjeksiyonu yapan testler yalnızca izole sandbox'ta koşar;
# gerçek masaüstünde yalnızca salt-okuma testleri çalışır.
set -u
cd "$(dirname "$0")/.."
fail=0
# 77 = gereken bileşimci/araç yok, test atlandı (başarısızlık sayılmaz)
run() {
    echo; echo "▶ $1"; shift
    "$@" 2>&1 | grep -E '✓|✗|⊘|SONUÇ|SNAPSHOT|KABUL|SANDBOX|MCP:|HTTP:|WLROOTS|WINDOWS|MACOS|PLATFORM|İMLEÇ|ELECTRON|SWAY|DAEMON|KARE|atlandı'
    local rc=${PIPESTATUS[0]}
    [[ $rc -eq 0 || $rc -eq 77 ]] || fail=1
}
run "duman (salt okuma)"        python3 tests/test_smoke.py
run "anlık görüntü ref + kira (sahte)"  python3 tests/test_snapshot.py
run "ekran yayını karesi (sahte)"  python3 tests/test_frame.py
run "kabul (salt okuma)"        python3 tests/test_acceptance.py
run "MCP stdio (salt okuma)"    python3 tests/test_mcp_stdio.py
run "HTTP güvenlik (salt okuma)" python3 tests/test_http.py
run "Sway/Hyprland (sahte IPC)"  python3 tests/test_wlroots_fake.py
run "macOS mantık (sahte Quartz)"  python3 tests/test_macos_logic.py
run "X11 — Xvfb sandbox"        tests/x11_sandbox.sh python3 tests/test_x11_sandbox.py
run "imleç teması (sahte tema)"    python3 tests/test_cursor_theme.py
run "ajan imleci — eylem geri bildirimi"  python3 tests/test_cursor_feedback.py
run "ajan imleci — daemon/taşıma"  python3 tests/test_cursor_daemon.py
run "ajan imleci — macOS (sahte objc)"  python3 tests/test_cursor_macos.py
run "ajan imleci — Xvfb"         tests/x11_sandbox.sh python3 tests/test_cursor_x11.py
if [[ -f "$HOME/.cache/nexremote-wine/python/python.exe" ]]; then
    run "Windows — Wine"            tests/wine/run.sh tests/test_windows_wine.py
    run "ajan imleci — Wine"        tests/wine/run.sh tests/test_cursor_wine.py
else
    echo; echo "▶ Windows — Wine"; echo "  ⊘ Wine kurulu değil (tests/wine/setup.sh) — atlandı"
fi
run "giriş — sandbox"           tests/sandbox.sh python3 tests/test_input_sandbox.py
run "CLI uçtan uca — sandbox"   tests/sandbox.sh bash -c 'cd tests && python3 test_cli_sandbox.py'
run "gerçek Sway — başsız"      tests/sway_sandbox.sh python3 tests/test_sway_sandbox.py
run "Electron — sandbox"        tests/sandbox.sh bash -c 'cd tests && python3 test_electron_sandbox.py'
echo; [[ $fail -eq 0 ]] && echo "TÜMÜ GEÇTİ" || echo "BAŞARISIZ TEST VAR"
exit $fail
